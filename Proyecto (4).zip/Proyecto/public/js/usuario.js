function abrirModal() {
    var modal = document.getElementById('modalCrearusuario');
    modal.style.display = "block";
}

// Función para cerrar el modal
function cerrarModal() {
    var modal = document.getElementById('modalCrearusuario');
    modal.style.display = "none";
}

// Función para agregar un nuevo usuario
function agregarUsuario() {
    var usuario = document.getElementById('inputUser').value;
    var correo = document.getElementById('inputCorreo').value;
    var rol = document.getElementById('inputRol').value;

    // Aquí puedes hacer lo que necesites con los datos del nuevo usuario, como enviarlos a un servidor o agregarlos dinámicamente a la tabla de usuarios
    
    // Después de agregar el usuario, cierra el modal
    cerrarModal();
}